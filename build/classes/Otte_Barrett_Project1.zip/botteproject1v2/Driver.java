/*
File: Driver.java
Author: Barrett Otte
Date: 06-15-2017
Summary: This was made to run the GUIParser. This was supposed to contain more
            code, but right now it just creates the GUIParser instance.
*/

package botteproject1v2;

public class Driver {
    public static void main(String[] args){
        GUIParser p = new GUIParser();
    }  
}
